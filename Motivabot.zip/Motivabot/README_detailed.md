# 💬 MotivaBot: Your Personal Motivation Coach

MotivaBot is a fine-tuned language model built on top of `google/flan-t5-small`, designed to generate motivational quotes based on users’ emotional states. Whether you're feeling stuck, overwhelmed, or unmotivated, MotivaBot offers uplifting messages to get you back on track.

This project demonstrates how to fine-tune a pre-trained Large Language Model (LLM) on a small, domain-specific dataset using the Hugging Face Transformers ecosystem.

---

## 📁 Project Structure

```
MotivaBot/
├── motivabot_dataset.jsonl        # Custom dataset: 250 mood-quote pairs
├── motivabot_finetuning.ipynb     # Colab/Jupyter notebook with full code
├── requirements.txt               # List of Python dependencies
├── README.md                      # Project documentation
└── app.py (optional)              # Gradio app for deployment
```

---

## 🚀 How to Run This Project

### 🔧 1. Set up your environment

You can run this project in:
- [Google Colab](https://colab.research.google.com/)
- Jupyter Notebook (local with GPU if possible)
- Any Python 3.8+ environment

### 🛠️ 2. Install Dependencies

Install required packages using:

```bash
pip install -r requirements.txt
```

This installs:
- `transformers`: Hugging Face model library
- `datasets`: Dataset loading & splitting
- `gradio`: Web UI interface
- `torch`: PyTorch (model backend)
- `accelerate`, `peft`, `bitsandbytes`: For fine-tuning optimization

### 📥 3. Load and Preprocess Dataset

Run the notebook `motivabot_finetuning.ipynb` to:
- Load `motivabot_dataset.jsonl`
- Preprocess input/output pairs
- Split into training and test sets

### 🧠 4. Tokenize and Load Model

The script uses `google/flan-t5-small` and tokenizes inputs with:
```python
tokenizer = AutoTokenizer.from_pretrained("google/flan-t5-small")
model = AutoModelForSeq2SeqLM.from_pretrained("google/flan-t5-small")
```

### 🏋️ 5. Fine-Tune the Model

You can configure training arguments inside the notebook:
```python
TrainingArguments(
    output_dir="./motivabot-model",
    num_train_epochs=5,
    per_device_train_batch_size=8,
    learning_rate=3e-4,
    ...
)
```

Use Hugging Face `Trainer` to start training:
```python
trainer = Trainer(...)
trainer.train()
```

---

## 💡 How to Test the Model

### 🧪 Inference Cell

Once trained, test with:

```python
input_text = "Motivate: I feel like a failure"
inputs = tokenizer(input_text, return_tensors="pt").input_ids.to(device)
outputs = model.generate(inputs, ...)
print(tokenizer.decode(outputs[0], skip_special_tokens=True))
```

### 🌐 Optional: Launch the Gradio Web App

To interact with the model in a chatbot format:

```python
!pip install gradio
python app.py
```

Gradio will launch a web UI where you can type a mood and get a motivational quote back.

---

## 📦 Dependencies

- `transformers`
- `datasets`
- `torch`
- `gradio`
- `accelerate`
- `peft`
- `bitsandbytes`

All listed in `requirements.txt`.

---

## 🙏 Acknowledgements

- Hugging Face Transformers & Datasets
- Google’s Flan-T5 model
- Gradio team for UI tools
- INFO 7375: Branding & AI @ Northeastern University

---

## 📫 Contact

Developed by **Sreeja**  
Feel free to use or adapt this project for your own fine-tuning workflows or LLM experiments.
